/*顶部导航栏的下拉菜单*/
const topnavItem = document.querySelectorAll(".app-header-nav-item")

topnavItem.forEach(item => {
    const layer = item.querySelector(".layer")

    item.addEventListener("mouseenter",()=>{
        layer.classList.add('show')
    })

    item.addEventListener('mouseleave',()=>{
        layer.classList.remove('show')
    })
})